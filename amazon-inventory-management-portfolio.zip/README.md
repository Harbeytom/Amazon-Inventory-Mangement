# Amazon Inventory Management Portfolio

A portfolio demonstration of inventory organization and replenishment planning for Amazon FBA and FBM sellers. All product names, ASINs, SKUs, quantities, sales figures, and scenarios in this repository are fictional and created for demonstration purposes. This is not a live connection to Amazon Seller Central.

## Project Goals
- Organize product-level inventory information by SKU and ASIN.
- Illustrate the difference between FBA and FBM inventory monitoring.
- Flag products that may need replenishment.
- Demonstrate a simple reorder-planning workflow.
- Present inventory findings in clear, seller-friendly reports.

## Repository Contents
- `data/amazon_fba_inventory.csv` — sample FBA inventory records.
- `data/amazon_fbm_inventory.csv` — sample FBM inventory records.
- `data/replenishment_report.csv` — sample restock planning output.
- `spreadsheets/Amazon_Inventory_Portfolio.xlsx` — workbook with FBA, FBM, replenishment, and summary worksheets.
- `case_studies/inventory_optimization_case_study.md` — fictional example case study.
- `case_studies/upwork_portfolio_description.md` — reusable portfolio summary.

## Example Workflow
1. Review each SKU's available stock and recent average daily sales.
2. Compare available stock with estimated days of cover.
3. Flag items below the sample reorder threshold.
4. Estimate a suggested reorder quantity using the target coverage period and supplier lead time.
5. Review assumptions before placing any purchase order.

## Example Planning Logic
- **Estimated days of cover** = available inventory ÷ average daily sales.
- **Reorder point** = average daily sales × (supplier lead time + safety-stock days).
- **Suggested reorder quantity** = max(0, target stock level − available inventory).

These are illustrative planning calculations, not guaranteed forecasts. Actual decisions should account for inbound inventory, reserved units, seasonality, supplier constraints, Amazon storage limits, fees, and the seller's own replenishment policy.

## How to Use
Open the workbook in Microsoft Excel or a compatible spreadsheet application. Replace the fictional rows with authorized, current seller data before using the workbook operationally. Review formulas and assumptions before making purchasing decisions.

## Tools Demonstrated
- Inventory data organization (CSV)
- Spreadsheet formulas and conditional formatting
- Basic replenishment planning
- Operational reporting and documentation

## Important Limitations
This portfolio project does not connect to Amazon Seller Central and does not use the Amazon Selling Partner API. It does not claim real client results. All data and the case study are simulated to demonstrate a possible workflow.
